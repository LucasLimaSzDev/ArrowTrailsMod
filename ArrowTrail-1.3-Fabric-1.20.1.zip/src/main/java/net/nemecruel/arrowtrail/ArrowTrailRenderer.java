package net.nemecruel.arrowtrail;

import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

import java.util.List;

public final class ArrowTrailRenderer {
    private ArrowTrailRenderer() {
    }

    public static void render(WorldRenderContext context) {
        List<ArrowTrailTracker.TrailSnapshot> trails =
                ArrowTrailTracker.snapshots(context.tickDelta());

        if (trails.isEmpty()) {
            return;
        }

        ClientWorld world = context.world();
        if (world == null) {
            return;
        }

        Vec3d camera = context.camera().getPos();
        Matrix4f matrix = context.matrixStack().peek().getPositionMatrix();

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();
        RenderSystem.enableDepthTest();
        RenderSystem.setShader(GameRenderer::getPositionColorProgram);

        BufferBuilder buffer = Tessellator.getInstance().getBuffer();
        buffer.begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);

        for (ArrowTrailTracker.TrailSnapshot trail : trails) {
            List<Vec3d> points = trail.points();
            if (points.size() < 2 || trail.visibleLength() <= 0.0001D) {
                continue;
            }

            int color = trail.color();
            float red = ((color >> 16) & 0xFF) / 255.0F;
            float green = ((color >> 8) & 0xFF) / 255.0F;
            float blue = (color & 0xFF) / 255.0F;
            float baseWidth = trail.width();
            float globalAlpha = trail.alpha();

            double remaining = trail.visibleLength();

            for (int i = 0; i < points.size() - 1 && remaining > 0.0001D; i++) {
                Vec3d point = points.get(i);
                Vec3d next = points.get(i + 1);
                Vec3d segment = next.subtract(point);
                double segmentLength = segment.length();

                if (segmentLength < 0.000001D) {
                    continue;
                }

                double drawnLength = Math.min(segmentLength, remaining);
                Vec3d endPoint = drawnLength >= segmentLength
                        ? next
                        : point.add(segment.multiply(drawnLength / segmentLength));

                Vec3d start = point.subtract(camera);
                Vec3d end = endPoint.subtract(camera);

                Vec3d side = segment.crossProduct(camera.subtract(point));
                if (side.lengthSquared() < 0.000001D) {
                    side = segment.crossProduct(new Vec3d(0.0D, 1.0D, 0.0D));
                }
                if (side.lengthSquared() < 0.000001D) {
                    side = segment.crossProduct(new Vec3d(1.0D, 0.0D, 0.0D));
                }

                float progress = (float) (i / (double) Math.max(1, points.size() - 1));
                float widthScale = 1.0F - progress * 0.58F;
                Vec3d halfWidth = side.normalize().multiply(baseWidth * widthScale);

                // The tail naturally fades thinner, while the head remains crisp.
                float alpha = globalAlpha * (1.0F - progress * 0.84F);

                buffer.vertex(matrix,
                                (float) (start.x + halfWidth.x),
                                (float) (start.y + halfWidth.y),
                                (float) (start.z + halfWidth.z))
                        .color(red, green, blue, alpha).next();
                buffer.vertex(matrix,
                                (float) (start.x - halfWidth.x),
                                (float) (start.y - halfWidth.y),
                                (float) (start.z - halfWidth.z))
                        .color(red, green, blue, alpha).next();
                buffer.vertex(matrix,
                                (float) (end.x - halfWidth.x),
                                (float) (end.y - halfWidth.y),
                                (float) (end.z - halfWidth.z))
                        .color(red, green, blue, alpha).next();
                buffer.vertex(matrix,
                                (float) (end.x + halfWidth.x),
                                (float) (end.y + halfWidth.y),
                                (float) (end.z + halfWidth.z))
                        .color(red, green, blue, alpha).next();

                remaining -= drawnLength;
            }
        }

        BufferRenderer.drawWithGlobalProgram(buffer.end());

        RenderSystem.enableCull();
        RenderSystem.disableBlend();
    }
}
