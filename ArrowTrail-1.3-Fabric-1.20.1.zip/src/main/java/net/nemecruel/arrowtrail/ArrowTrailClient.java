package net.nemecruel.arrowtrail;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.projectile.ArrowEntity;
import net.minecraft.entity.projectile.PersistentProjectileEntity;
import net.minecraft.entity.projectile.SpectralArrowEntity;

public final class ArrowTrailClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        ClientTickEvents.END_CLIENT_TICK.register(ArrowTrailClient::tick);
        WorldRenderEvents.LAST.register(ArrowTrailRenderer::render);
    }

    private static void tick(MinecraftClient client) {
        ClientWorld world = client.world;
        if (world == null) {
            return;
        }

        for (Entity entity : world.getEntities()) {
            if (!(entity instanceof PersistentProjectileEntity projectile)) {
                continue;
            }

            if (!(projectile instanceof ArrowEntity) && !(projectile instanceof SpectralArrowEntity)) {
                continue;
            }

            ArrowTrailTracker.register(projectile);
        }

        ArrowTrailTracker.tick(world);
    }
}
