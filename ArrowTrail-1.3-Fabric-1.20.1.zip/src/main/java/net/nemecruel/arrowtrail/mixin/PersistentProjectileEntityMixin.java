package net.nemecruel.arrowtrail.mixin;

import net.minecraft.entity.projectile.PersistentProjectileEntity;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.world.World;
import net.nemecruel.arrowtrail.ArrowTrailTracker;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(PersistentProjectileEntity.class)
public abstract class PersistentProjectileEntityMixin {
    @Redirect(
            method = "tick",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/world/World;addParticle(Lnet/minecraft/particle/ParticleEffect;DDDDDD)V"
            )
    )
    private void arrowtrail$suppressVanillaArrowParticle(
            World world,
            ParticleEffect particle,
            double x,
            double y,
            double z,
            double velocityX,
            double velocityY,
            double velocityZ) {
        // Intentionally empty: only the vanilla arrow particle is suppressed.
        // The projectile tick itself continues normally.
    }

    @Inject(method = "onBlockHit", at = @At("TAIL"))
    private void arrowtrail$onBlockHit(BlockHitResult hitResult, CallbackInfo ci) {
        ArrowTrailTracker.onImpact((PersistentProjectileEntity) (Object) this);
    }

    @Inject(method = "onEntityHit", at = @At("TAIL"))
    private void arrowtrail$onEntityHit(EntityHitResult hitResult, CallbackInfo ci) {
        ArrowTrailTracker.onImpact((PersistentProjectileEntity) (Object) this);
    }
}
