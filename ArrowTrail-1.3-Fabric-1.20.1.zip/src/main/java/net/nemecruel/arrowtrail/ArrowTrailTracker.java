package net.nemecruel.arrowtrail;

import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.projectile.ArrowEntity;
import net.minecraft.entity.projectile.PersistentProjectileEntity;
import net.minecraft.entity.projectile.SpectralArrowEntity;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Tracks the visual history of arrows independently from Minecraft's projectile
 * movement. The trail is sampled in world space and then interpolated during
 * rendering, so fast arrows do not leave a stiff, disconnected tail.
 */
public final class ArrowTrailTracker {
    private static final double BASE_MAX_LENGTH = 2.05D;
    private static final double FAST_LENGTH_BONUS = 0.14D;
    private static final double FAST_REFERENCE_SPEED = 3.0D;
    private static final double MIN_POINT_DISTANCE_SQUARED = 0.0064D;
    private static final double MIN_MOVEMENT_SQUARED = 0.000001D;
    private static final double TAIL_OFFSET = 0.32D;
    private static final int RETRACT_TICKS = 12;

    private static final Map<UUID, TrailState> TRAILS = new HashMap<>();

    private ArrowTrailTracker() {
    }

    /** Register only while the projectile is genuinely moving. */
    public static void register(PersistentProjectileEntity projectile) {
        if (!isArrow(projectile) || !projectile.isAlive() || isStopped(projectile)) {
            return;
        }

        TRAILS.computeIfAbsent(projectile.getUuid(), id -> new TrailState(projectile));
    }

    /** Called by the projectile mixin as soon as Minecraft resolves a hit. */
    public static void onImpact(PersistentProjectileEntity projectile) {
        TrailState state = TRAILS.get(projectile.getUuid());
        if (state != null) {
            state.beginRetract();
        }
    }

    public static void tick(ClientWorld world) {
        Iterator<Map.Entry<UUID, TrailState>> iterator = TRAILS.entrySet().iterator();

        while (iterator.hasNext()) {
            TrailState state = iterator.next().getValue();
            Entity entity = state.entity;

            if (!(entity instanceof PersistentProjectileEntity projectile)
                    || projectile.getWorld() != world
                    || !isArrow(projectile)
                    || !projectile.isAlive()) {
                state.beginRetract();
            } else if (!state.retracting) {
                Vec3d position = projectile.getPos();
                Vec3d velocity = projectile.getVelocity();

                boolean moving = position.squaredDistanceTo(state.lastPosition) > MIN_MOVEMENT_SQUARED
                        || velocity.lengthSquared() > MIN_MOVEMENT_SQUARED;

                if (!moving || projectile.isOnGround()) {
                    state.beginRetract();
                } else {
                    state.lastPosition = position;

                    Vec3d tail = calculateTail(position, velocity);
                    state.previousTail = state.currentTail;
                    state.currentTail = tail;

                    // Keep the newest sample. The renderer interpolates this
                    // point between client ticks, which makes fast shots look
                    // attached to the arrow instead of snapping once per tick.
                    if (state.points.isEmpty()
                            || state.points.peekFirst().squaredDistanceTo(tail) >= MIN_POINT_DISTANCE_SQUARED) {
                        state.points.addFirst(tail);
                        trimToLength(state.points, adaptiveMaxLength(velocity));
                    }
                }
            }

            if (state.retracting) {
                state.retractTicks++;
                if (state.retractTicks > RETRACT_TICKS) {
                    iterator.remove();
                }
            }
        }
    }

    public static List<TrailSnapshot> snapshots(float tickDelta) {
        List<TrailSnapshot> result = new ArrayList<>();

        for (TrailState state : TRAILS.values()) {
            if (state.points.size() < 2) {
                continue;
            }

            // The head is interpolated every render frame. This is the key part
            // that keeps the back of the trail visually locked to a fast arrow.
            List<Vec3d> points = new ArrayList<>(state.points);
            if (!state.retracting) {
                points.set(0, interpolate(state.previousTail, state.currentTail, tickDelta));
            }

            double totalLength = lengthOf(points);
            if (totalLength <= 0.0001D) {
                continue;
            }

            float progress = state.retracting
                    ? Math.min(1.0F, (state.retractTicks - 1.0F + tickDelta) / RETRACT_TICKS)
                    : 0.0F;

            // Smoothstep-like ease: starts gently, accelerates, then settles.
            float eased = progress * progress * (3.0F - 2.0F * progress);
            double visibleLength = totalLength * (1.0D - eased);

            float widthScale = 1.0F - eased * 0.28F;
            float alpha = state.retracting
                    ? smoothFade(1.0F - progress)
                    : 1.0F;

            result.add(new TrailSnapshot(
                    points,
                    state.color,
                    state.width * widthScale,
                    visibleLength,
                    alpha
            ));
        }

        return result;
    }

    private static float smoothFade(float value) {
        value = Math.max(0.0F, Math.min(1.0F, value));
        return value * value * (3.0F - 2.0F * value);
    }

    private static Vec3d calculateTail(Vec3d position, Vec3d velocity) {
        if (velocity.lengthSquared() <= MIN_MOVEMENT_SQUARED) {
            return position;
        }
        return position.subtract(velocity.normalize().multiply(TAIL_OFFSET));
    }

    private static Vec3d interpolate(Vec3d from, Vec3d to, float amount) {
        double t = Math.max(0.0D, Math.min(1.0D, amount));
        return new Vec3d(
                from.x + (to.x - from.x) * t,
                from.y + (to.y - from.y) * t,
                from.z + (to.z - from.z) * t
        );
    }

    private static boolean isArrow(PersistentProjectileEntity projectile) {
        return projectile instanceof ArrowEntity || projectile instanceof SpectralArrowEntity;
    }

    private static boolean isStopped(PersistentProjectileEntity projectile) {
        return projectile.isOnGround() || projectile.getVelocity().lengthSquared() <= MIN_MOVEMENT_SQUARED;
    }

    /**
     * Trims to an exact maximum length instead of deleting the entire last
     * segment. This is important for fast arrows: their per-tick movement can
     * be larger than the desired trail length.
     */
    private static double adaptiveMaxLength(Vec3d velocity) {
        double speed = velocity.length();
        double speedFactor = Math.max(0.0D, Math.min(1.0D, speed / FAST_REFERENCE_SPEED));
        return BASE_MAX_LENGTH + FAST_LENGTH_BONUS * speedFactor;
    }

    private static void trimToLength(Deque<Vec3d> points, double maxLength) {
        if (points.size() < 2) {
            return;
        }

        Deque<Vec3d> trimmed = new ArrayDeque<>();
        Vec3d previous = null;
        double length = 0.0D;

        for (Vec3d point : points) {
            if (previous == null) {
                trimmed.addLast(point);
                previous = point;
                continue;
            }

            double segmentLength = point.distanceTo(previous);
            if (length + segmentLength >= maxLength) {
                double remaining = maxLength - length;
                if (segmentLength > 0.000001D && remaining > 0.000001D) {
                    double ratio = remaining / segmentLength;
                    trimmed.addLast(new Vec3d(
                            previous.x + (point.x - previous.x) * ratio,
                            previous.y + (point.y - previous.y) * ratio,
                            previous.z + (point.z - previous.z) * ratio
                    ));
                }
                break;
            }

            trimmed.addLast(point);
            length += segmentLength;
            previous = point;
        }

        points.clear();
        points.addAll(trimmed);
    }

    private static double lengthOf(List<Vec3d> points) {
        double length = 0.0D;
        Vec3d previous = null;

        for (Vec3d point : points) {
            if (previous != null) {
                length += point.distanceTo(previous);
            }
            previous = point;
        }

        return length;
    }

    public record TrailSnapshot(
            List<Vec3d> points,
            int color,
            float width,
            double visibleLength,
            float alpha
    ) {
    }

    private static final class TrailState {
        private final Entity entity;
        private final Deque<Vec3d> points = new ArrayDeque<>();
        private final int color;
        private final float width;
        private Vec3d lastPosition;
        private Vec3d previousTail;
        private Vec3d currentTail;
        private boolean retracting;
        private int retractTicks;

        private TrailState(PersistentProjectileEntity projectile) {
            this.entity = projectile;
            Vec3d initial = calculateTail(projectile.getPos(), projectile.getVelocity());
            this.lastPosition = projectile.getPos();
            this.previousTail = initial;
            this.currentTail = initial;
            this.color = getColor(projectile);
            this.width = projectile instanceof SpectralArrowEntity ? 0.070F : 0.052F;
            this.points.addFirst(initial);
        }

        private void beginRetract() {
            retracting = true;
        }

        private static int getColor(PersistentProjectileEntity projectile) {
            if (projectile instanceof SpectralArrowEntity) {
                return 0xFFF1A8;
            }

            if (projectile instanceof ArrowEntity arrow) {
                int color = arrow.getColor();
                return color == -1 ? 0xE8E8E8 : color;
            }

            return 0xE8E8E8;
        }
    }
}
