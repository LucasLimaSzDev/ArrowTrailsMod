@echo off
setlocal EnableExtensions

set "APP_HOME=%~dp0"
set "WRAPPER_JAR=%APP_HOME%gradle\wrapper\gradle-wrapper.jar"
set "WRAPPER_URL=https://raw.githubusercontent.com/gradle/gradle/v8.8.0/gradle/wrapper/gradle-wrapper.jar"

if not exist "%WRAPPER_JAR%" (
    echo Gradle Wrapper JAR not found. Downloading the official Gradle 8.8 wrapper...
    powershell -NoProfile -ExecutionPolicy Bypass -Command ^
      "$ErrorActionPreference='Stop'; Invoke-WebRequest -UseBasicParsing -Uri '%WRAPPER_URL%' -OutFile '%WRAPPER_JAR%'"
    if errorlevel 1 (
        echo Failed to download the Gradle Wrapper JAR.
        exit /b 1
    )
)

where java >nul 2>nul
if errorlevel 1 (
    echo Java was not found in PATH.
    echo Install Java 17 and make sure java.exe is available in PATH.
    exit /b 1
)

"%JAVA_HOME%\bin\java.exe" -version >nul 2>nul
if errorlevel 1 set "JAVA_CMD=java"
if not defined JAVA_CMD set "JAVA_CMD=%JAVA_HOME%\bin\java.exe"

"%JAVA_CMD%" -classpath "%WRAPPER_JAR%" org.gradle.wrapper.GradleWrapperMain %*
exit /b %ERRORLEVEL%
