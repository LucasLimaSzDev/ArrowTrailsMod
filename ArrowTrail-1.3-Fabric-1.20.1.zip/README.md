# Arrow Trail

Client-side Fabric mod for Minecraft 1.20.1 that adds smooth custom trails to arrows.

## 1.3.0 — Polished Trail Lifecycle

- Custom continuous trail, without vanilla arrow particles.
- Tipped arrows use their vanilla arrow color.
- Spectral arrows use a brighter golden trail and a slightly wider line.
- Trail length is capped for a consistent appearance.
- Arrow block/entity impacts trigger an explicit retract animation.
- The trail retracts smoothly toward the arrow with easing, alpha fade and a subtle width reduction.
- Stopped arrows cannot recreate a trail after the previous trail has finished.
- The projectile's normal tick, movement and collision logic remain untouched.
- Includes Gradle Wrapper files for `gradlew.bat build`.
