package net.nemecruel.arrowtrail.mixin;

import net.minecraft.class_1665;
import net.minecraft.class_1937;
import net.minecraft.class_2394;
import net.minecraft.class_3965;
import net.minecraft.class_3966;
import net.nemecruel.arrowtrail.ArrowTrailTracker;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1665.class)
public abstract class PersistentProjectileEntityMixin {
    @Redirect(
            method = "tick",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/world/World;addParticle(Lnet/minecraft/particle/ParticleEffect;DDDDDD)V"
            )
    )
    private void arrowtrail$suppressVanillaArrowParticle(
            class_1937 world,
            class_2394 particle,
            double x,
            double y,
            double z,
            double velocityX,
            double velocityY,
            double velocityZ) {
        // Intentionally empty: only the vanilla arrow particle is suppressed.
        // The projectile tick itself continues normally.
    }

    @Inject(method = "onBlockHit", at = @At("TAIL"))
    private void arrowtrail$onBlockHit(class_3965 hitResult, CallbackInfo ci) {
        ArrowTrailTracker.onImpact((class_1665) (Object) this);
    }

    @Inject(method = "onEntityHit", at = @At("TAIL"))
    private void arrowtrail$onEntityHit(class_3966 hitResult, CallbackInfo ci) {
        ArrowTrailTracker.onImpact((class_1665) (Object) this);
    }
}
