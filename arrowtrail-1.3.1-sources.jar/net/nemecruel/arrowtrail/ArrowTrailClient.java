package net.nemecruel.arrowtrail;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.class_1297;
import net.minecraft.class_1665;
import net.minecraft.class_1667;
import net.minecraft.class_1679;
import net.minecraft.class_310;
import net.minecraft.class_638;

public final class ArrowTrailClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        ClientTickEvents.END_CLIENT_TICK.register(ArrowTrailClient::tick);
        WorldRenderEvents.LAST.register(ArrowTrailRenderer::render);
    }

    private static void tick(class_310 client) {
        class_638 world = client.field_1687;
        if (world == null) {
            return;
        }

        for (class_1297 entity : world.method_18112()) {
            if (!(entity instanceof class_1665 projectile)) {
                continue;
            }

            if (!(projectile instanceof class_1667) && !(projectile instanceof class_1679)) {
                continue;
            }

            ArrowTrailTracker.register(projectile);
        }

        ArrowTrailTracker.tick(world);
    }
}
