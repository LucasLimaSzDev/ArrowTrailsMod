package net.nemecruel.arrowtrail;

import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.class_243;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_638;
import net.minecraft.class_757;
import org.joml.Matrix4f;

import java.util.List;

public final class ArrowTrailRenderer {
    private ArrowTrailRenderer() {
    }

    public static void render(WorldRenderContext context) {
        List<ArrowTrailTracker.TrailSnapshot> trails =
                ArrowTrailTracker.snapshots(context.tickDelta());

        if (trails.isEmpty()) {
            return;
        }

        class_638 world = context.world();
        if (world == null) {
            return;
        }

        class_243 camera = context.camera().method_19326();
        Matrix4f matrix = context.matrixStack().method_23760().method_23761();

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();
        RenderSystem.enableDepthTest();
        RenderSystem.setShader(class_757::method_34540);

        class_287 buffer = class_289.method_1348().method_1349();
        buffer.method_1328(class_293.class_5596.field_27382, class_290.field_1576);

        for (ArrowTrailTracker.TrailSnapshot trail : trails) {
            List<class_243> points = trail.points();
            if (points.size() < 2 || trail.visibleLength() <= 0.0001D) {
                continue;
            }

            int color = trail.color();
            float red = ((color >> 16) & 0xFF) / 255.0F;
            float green = ((color >> 8) & 0xFF) / 255.0F;
            float blue = (color & 0xFF) / 255.0F;
            float baseWidth = trail.width();
            float globalAlpha = trail.alpha();

            double remaining = trail.visibleLength();

            for (int i = 0; i < points.size() - 1 && remaining > 0.0001D; i++) {
                class_243 point = points.get(i);
                class_243 next = points.get(i + 1);
                class_243 segment = next.method_1020(point);
                double segmentLength = segment.method_1033();

                if (segmentLength < 0.000001D) {
                    continue;
                }

                double drawnLength = Math.min(segmentLength, remaining);
                class_243 endPoint = drawnLength >= segmentLength
                        ? next
                        : point.method_1019(segment.method_1021(drawnLength / segmentLength));

                class_243 start = point.method_1020(camera);
                class_243 end = endPoint.method_1020(camera);

                class_243 side = segment.method_1036(camera.method_1020(point));
                if (side.method_1027() < 0.000001D) {
                    side = segment.method_1036(new class_243(0.0D, 1.0D, 0.0D));
                }
                if (side.method_1027() < 0.000001D) {
                    side = segment.method_1036(new class_243(1.0D, 0.0D, 0.0D));
                }

                float progress = (float) (i / (double) Math.max(1, points.size() - 1));
                float widthScale = 1.0F - progress * 0.58F;
                class_243 halfWidth = side.method_1029().method_1021(baseWidth * widthScale);

                // The tail naturally fades thinner, while the head remains crisp.
                float alpha = globalAlpha * (1.0F - progress * 0.84F);

                buffer.method_22918(matrix,
                                (float) (start.field_1352 + halfWidth.field_1352),
                                (float) (start.field_1351 + halfWidth.field_1351),
                                (float) (start.field_1350 + halfWidth.field_1350))
                        .method_22915(red, green, blue, alpha).method_1344();
                buffer.method_22918(matrix,
                                (float) (start.field_1352 - halfWidth.field_1352),
                                (float) (start.field_1351 - halfWidth.field_1351),
                                (float) (start.field_1350 - halfWidth.field_1350))
                        .method_22915(red, green, blue, alpha).method_1344();
                buffer.method_22918(matrix,
                                (float) (end.field_1352 - halfWidth.field_1352),
                                (float) (end.field_1351 - halfWidth.field_1351),
                                (float) (end.field_1350 - halfWidth.field_1350))
                        .method_22915(red, green, blue, alpha).method_1344();
                buffer.method_22918(matrix,
                                (float) (end.field_1352 + halfWidth.field_1352),
                                (float) (end.field_1351 + halfWidth.field_1351),
                                (float) (end.field_1350 + halfWidth.field_1350))
                        .method_22915(red, green, blue, alpha).method_1344();

                remaining -= drawnLength;
            }
        }

        class_286.method_43433(buffer.method_1326());

        RenderSystem.enableCull();
        RenderSystem.disableBlend();
    }
}
