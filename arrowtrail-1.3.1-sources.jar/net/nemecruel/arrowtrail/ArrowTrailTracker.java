package net.nemecruel.arrowtrail;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.minecraft.class_1297;
import net.minecraft.class_1665;
import net.minecraft.class_1667;
import net.minecraft.class_1679;
import net.minecraft.class_243;
import net.minecraft.class_638;

/**
 * Tracks the visual history of arrows independently from Minecraft's projectile
 * movement. The trail is sampled in world space and then interpolated during
 * rendering, so fast arrows do not leave a stiff, disconnected tail.
 */
public final class ArrowTrailTracker {
    private static final double BASE_MAX_LENGTH = 2.05D;
    private static final double FAST_LENGTH_BONUS = 0.14D;
    private static final double FAST_REFERENCE_SPEED = 3.0D;
    private static final double MIN_POINT_DISTANCE_SQUARED = 0.0064D;
    private static final double MIN_MOVEMENT_SQUARED = 0.000001D;
    private static final double TAIL_OFFSET = 0.32D;
    private static final int RETRACT_TICKS = 12;

    private static final Map<UUID, TrailState> TRAILS = new HashMap<>();

    private ArrowTrailTracker() {
    }

    /** Register only while the projectile is genuinely moving. */
    public static void register(class_1665 projectile) {
        if (!isArrow(projectile) || !projectile.method_5805() || isStopped(projectile)) {
            return;
        }

        TRAILS.computeIfAbsent(projectile.method_5667(), id -> new TrailState(projectile));
    }

    /** Called by the projectile mixin as soon as Minecraft resolves a hit. */
    public static void onImpact(class_1665 projectile) {
        TrailState state = TRAILS.get(projectile.method_5667());
        if (state != null) {
            state.beginRetract();
        }
    }

    public static void tick(class_638 world) {
        Iterator<Map.Entry<UUID, TrailState>> iterator = TRAILS.entrySet().iterator();

        while (iterator.hasNext()) {
            TrailState state = iterator.next().getValue();
            class_1297 entity = state.entity;

            if (!(entity instanceof class_1665 projectile)
                    || projectile.method_37908() != world
                    || !isArrow(projectile)
                    || !projectile.method_5805()) {
                state.beginRetract();
            } else if (!state.retracting) {
                class_243 position = projectile.method_19538();
                class_243 velocity = projectile.method_18798();

                boolean moving = position.method_1025(state.lastPosition) > MIN_MOVEMENT_SQUARED
                        || velocity.method_1027() > MIN_MOVEMENT_SQUARED;

                if (!moving || projectile.method_24828()) {
                    state.beginRetract();
                } else {
                    state.lastPosition = position;

                    class_243 tail = calculateTail(position, velocity);
                    state.previousTail = state.currentTail;
                    state.currentTail = tail;

                    // Keep the newest sample. The renderer interpolates this
                    // point between client ticks, which makes fast shots look
                    // attached to the arrow instead of snapping once per tick.
                    if (state.points.isEmpty()
                            || state.points.peekFirst().method_1025(tail) >= MIN_POINT_DISTANCE_SQUARED) {
                        state.points.addFirst(tail);
                        trimToLength(state.points, adaptiveMaxLength(velocity));
                    }
                }
            }

            if (state.retracting) {
                state.retractTicks++;
                if (state.retractTicks > RETRACT_TICKS) {
                    iterator.remove();
                }
            }
        }
    }

    public static List<TrailSnapshot> snapshots(float tickDelta) {
        List<TrailSnapshot> result = new ArrayList<>();

        for (TrailState state : TRAILS.values()) {
            if (state.points.size() < 2) {
                continue;
            }

            // The head is interpolated every render frame. This is the key part
            // that keeps the back of the trail visually locked to a fast arrow.
            List<class_243> points = new ArrayList<>(state.points);
            if (!state.retracting) {
                points.set(0, interpolate(state.previousTail, state.currentTail, tickDelta));
            }

            double totalLength = lengthOf(points);
            if (totalLength <= 0.0001D) {
                continue;
            }

            float progress = state.retracting
                    ? Math.min(1.0F, (state.retractTicks - 1.0F + tickDelta) / RETRACT_TICKS)
                    : 0.0F;

            // Smoothstep-like ease: starts gently, accelerates, then settles.
            float eased = progress * progress * (3.0F - 2.0F * progress);
            double visibleLength = totalLength * (1.0D - eased);

            float widthScale = 1.0F - eased * 0.28F;
            float alpha = state.retracting
                    ? smoothFade(1.0F - progress)
                    : 1.0F;

            result.add(new TrailSnapshot(
                    points,
                    state.color,
                    state.width * widthScale,
                    visibleLength,
                    alpha
            ));
        }

        return result;
    }

    private static float smoothFade(float value) {
        value = Math.max(0.0F, Math.min(1.0F, value));
        return value * value * (3.0F - 2.0F * value);
    }

    private static class_243 calculateTail(class_243 position, class_243 velocity) {
        if (velocity.method_1027() <= MIN_MOVEMENT_SQUARED) {
            return position;
        }
        return position.method_1020(velocity.method_1029().method_1021(TAIL_OFFSET));
    }

    private static class_243 interpolate(class_243 from, class_243 to, float amount) {
        double t = Math.max(0.0D, Math.min(1.0D, amount));
        return new class_243(
                from.field_1352 + (to.field_1352 - from.field_1352) * t,
                from.field_1351 + (to.field_1351 - from.field_1351) * t,
                from.field_1350 + (to.field_1350 - from.field_1350) * t
        );
    }

    private static boolean isArrow(class_1665 projectile) {
        return projectile instanceof class_1667 || projectile instanceof class_1679;
    }

    private static boolean isStopped(class_1665 projectile) {
        return projectile.method_24828() || projectile.method_18798().method_1027() <= MIN_MOVEMENT_SQUARED;
    }

    /**
     * Trims to an exact maximum length instead of deleting the entire last
     * segment. This is important for fast arrows: their per-tick movement can
     * be larger than the desired trail length.
     */
    private static double adaptiveMaxLength(class_243 velocity) {
        double speed = velocity.method_1033();
        double speedFactor = Math.max(0.0D, Math.min(1.0D, speed / FAST_REFERENCE_SPEED));
        return BASE_MAX_LENGTH + FAST_LENGTH_BONUS * speedFactor;
    }

    private static void trimToLength(Deque<class_243> points, double maxLength) {
        if (points.size() < 2) {
            return;
        }

        Deque<class_243> trimmed = new ArrayDeque<>();
        class_243 previous = null;
        double length = 0.0D;

        for (class_243 point : points) {
            if (previous == null) {
                trimmed.addLast(point);
                previous = point;
                continue;
            }

            double segmentLength = point.method_1022(previous);
            if (length + segmentLength >= maxLength) {
                double remaining = maxLength - length;
                if (segmentLength > 0.000001D && remaining > 0.000001D) {
                    double ratio = remaining / segmentLength;
                    trimmed.addLast(new class_243(
                            previous.field_1352 + (point.field_1352 - previous.field_1352) * ratio,
                            previous.field_1351 + (point.field_1351 - previous.field_1351) * ratio,
                            previous.field_1350 + (point.field_1350 - previous.field_1350) * ratio
                    ));
                }
                break;
            }

            trimmed.addLast(point);
            length += segmentLength;
            previous = point;
        }

        points.clear();
        points.addAll(trimmed);
    }

    private static double lengthOf(List<class_243> points) {
        double length = 0.0D;
        class_243 previous = null;

        for (class_243 point : points) {
            if (previous != null) {
                length += point.method_1022(previous);
            }
            previous = point;
        }

        return length;
    }

    public record TrailSnapshot(
            List<class_243> points,
            int color,
            float width,
            double visibleLength,
            float alpha
    ) {
    }

    private static final class TrailState {
        private final class_1297 entity;
        private final Deque<class_243> points = new ArrayDeque<>();
        private final int color;
        private final float width;
        private class_243 lastPosition;
        private class_243 previousTail;
        private class_243 currentTail;
        private boolean retracting;
        private int retractTicks;

        private TrailState(class_1665 projectile) {
            this.entity = projectile;
            class_243 initial = calculateTail(projectile.method_19538(), projectile.method_18798());
            this.lastPosition = projectile.method_19538();
            this.previousTail = initial;
            this.currentTail = initial;
            this.color = getColor(projectile);
            this.width = projectile instanceof class_1679 ? 0.070F : 0.052F;
            this.points.addFirst(initial);
        }

        private void beginRetract() {
            retracting = true;
        }

        private static int getColor(class_1665 projectile) {
            if (projectile instanceof class_1679) {
                return 0xFFF1A8;
            }

            if (projectile instanceof class_1667 arrow) {
                int color = arrow.method_7460();
                return color == -1 ? 0xE8E8E8 : color;
            }

            return 0xE8E8E8;
        }
    }
}
